import { View, Text } from 'react-native'
import React from 'react'

export default function Divider() {
  return (
    <View style={{height: 1,width: '100%',backgroundColor: '#BE9F56',marginTop: 20}}>
      
    </View>
  )
}